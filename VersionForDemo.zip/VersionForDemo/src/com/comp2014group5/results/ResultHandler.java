package com.comp2014group5.results;

public interface ResultHandler {

	public ResultEntry getResult();
	
}
