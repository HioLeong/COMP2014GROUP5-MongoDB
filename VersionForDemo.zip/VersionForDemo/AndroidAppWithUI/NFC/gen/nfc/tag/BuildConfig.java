/** Automatically generated file. DO NOT MODIFY */
package nfc.tag;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}