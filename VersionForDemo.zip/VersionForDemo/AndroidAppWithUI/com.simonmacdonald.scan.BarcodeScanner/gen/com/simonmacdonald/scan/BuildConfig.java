/** Automatically generated file. DO NOT MODIFY */
package com.simonmacdonald.scan;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}